package com.jljacoblo.simplelogin;

import java.util.Arrays;

import com.facebook.Request;
import com.facebook.Response;
import com.facebook.Session;
import com.facebook.SessionState;
import com.facebook.model.GraphUser;
import com.facebook.widget.LoginButton;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

public class MainActivity extends Activity {
	private TextView lblEmail;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		lblEmail = (TextView) findViewById(R.id.lblEmail);

		LoginButton authButton = (LoginButton) findViewById(R.id.authButton);

		final Request.GraphUserCallback rgucb = new Request.GraphUserCallback() {

			@Override
			public void onCompleted(GraphUser user, Response response) {
				if (user != null) { 
					// the user.getId is unique for every facebook user, If you got to the website : http://www.facebook.com/"user.getId()"
					lblEmail.setText(user.getId());
				}
			}
			
		};
		
		Session.StatusCallback sscb = new Session.StatusCallback() {

			@Override
			public void call(Session session, SessionState state, Exception exception) {
				if (session.isOpened()) {
					Request.executeMeRequestAsync(session,rgucb);
				}
				
			}
			
		};
		
		authButton.setSessionStatusCallback(sscb);
	}
	
	@Override
	 public void onActivityResult(int requestCode, int resultCode, Intent data) {
	     super.onActivityResult(requestCode, resultCode, data);
	     Session.getActiveSession().onActivityResult(this, requestCode, resultCode, data);
	 }
}
